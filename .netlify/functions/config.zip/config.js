var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// config.js
var config_exports = {};
__export(config_exports, {
  userCred: () => userCred
});
module.exports = __toCommonJS(config_exports);
var userCred = {
  accessToken: "BQCOXe3L_hPLrbCjgUivnv_DaHoqTPQpEplJm1ArRbFEa_R73UMZKjC92UI-UOwqeDOQVHAeTW6kJgC9k9BtV-bqI5hTdNLiCNt_vCLPWsOsw0N03MdrWFHH6XpeNR0HtWj-W1Doh_4HXnT4u0JdT3QdSixXETgZC6-YoK8zlZI95nxeYv-TszwYlyMF9sT3hmdwQMLpvK32N8LYEy6xmxaCWkORKFok-0FKBsJsU3RTvxhgECS8JbeZnRdj4AizQ4JuuMGEMdbXvGzzpO6vkDLXd038qh_CBigFEL6H8jA2wORk_8U35P6S7nzKsRMK7npEA-yrP-P7K0hdDEIlp6UyZPRmXg",
  clientToken: "AAAUsNGqYfPTF15K/7AKPgsB9PJfGZ//3tghkRZ73ROuMnmyYk++bajaKX0cFmJE0TeT7jk9876pOwlv42Ik9/rMPXpj6NpxVt/ZdD+5uDfar+x0l6apYBARgDNe0aBNTv8VqV8qnfWT1cxmhguVn5Yx9VdUJ4B03EYQjIO8PxFygxojmR236Ks0fYIcn7qv+ktKenxAfyCic9bjRhsZtQ8dhgRqgzTYhaYXnTKQhcF1jj0c1VRhVa+zuObJXrv3CnSH9KTWv6cqkYQYJ+wdFehu7AlUuKlq5IQarnRfzbdWo6Q=",
  emeKey: "AAAAU3Bzc2gAAAAA7e+LqXnWSs6jyCfc1R0h7QAAADMIARIQGEhw0yuWo4P/4Rs3Txv/cxoHc3BvdGlmeSIUGEhw0yuWo4P/4Rs3Txv/c+q2oGE="
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  userCred
});
